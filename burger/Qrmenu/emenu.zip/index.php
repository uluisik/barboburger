<?php include 'includes/header.php';?>
<?
  $masamiz=1;

  if($_GET["masa"] || !$_SESSION["masa"]){
    for ($i=0; $i < 1000; $i++) { 
      if(($_GET["masa"]) == md5($i)){
        $masamiz=$i;  
        $_SESSION["masa_no"]=$i;
        break;
      } 
    }
  } 
  
 
 
  
  ?>



<title>Anasayfa - <?=$ayar['sayfa_baslik'];?></title>
<?php include 'includes/navbar.php';?>


 


                  <!-- Slider -->

                 <div class="swiper-container slidertoolbar">

                    <div class="swiper-wrapper">

                    
                                  <?php



            $sorgu = $dbh->prepare("SELECT * FROM slider");

            $sorgu->execute();



            while ($sonuc = $sorgu->fetch()) {



                $id = $sonuc['id'];

                $baslik = $sonuc['baslik'];

                $ana_baslik = $sonuc['ana_baslik'];

                $aciklama = $sonuc['aciklama'];

                $foto = $sonuc['foto'];

                $sonuc = cevir("slider",$sonuc,$_SESSION["dil"]);

                ?>

                <div class="swiper-slide" style="background-image:url(img/<?=$sonuc['foto'];?>);">
                <div class="slider_trans">
                <div class="slider-caption">
                <span class="subtitle" data-swiper-parallax="-60%"><?=$sonuc['ana_baslik'];?></span> 
                <h2 data-swiper-parallax="-100%"><?=$sonuc['baslik']." ";?></h2> 
                <p data-swiper-parallax="-30%"><?=$sonuc['aciklama'];?></p> <br> 
                <a href="<?=$sonuc['buton'];?>"><center>  <span class="subtitle" data-swiper-parallax="-60%"><?php echo $dil["hemen-incele"];?></span> </center></a>
                </div>

		                   </div> 

                       </div>

                      <?php } ?>
                     

                    </div>

                    <div class="swiper-pagination"></div>

			<div class="swiper-button-prev"></div>

			<div class="swiper-button-next"></div>	

                  </div>

			  

		 <div class="swiper-container-toolbar">

			<div class="swiper-pagination-toolbar"></div>

			<div class="swiper-wrapper">

			  <div class="swiper-slide toolbar-icon">

     

        <a    href="#" style="font-size:10px;background:transparent"   >     
        <span class="subtitle" data-swiper-parallax="-60%" style="transform: translate3d(0%, 0px, 0px);    width: 100%;
    margin: 0;
    font-size: 10px;
    padding: 5px;
    font-weight: 300;
    color: #fff;
    background-color: #000;
    display: inline;">
              <?
                if(isset( $_SESSION["masa_no"])){

                  $sth = $dbh->prepare("select * from masa_no where id=".$_SESSION["masa_no"]);
                  $sth->execute();
                  $masa_ = $sth->fetch(PDO::FETCH_ASSOC);
                  echo $masa_["masa_adi"];
                    
                }else{
                  echo $dil["masa_secilmedi"];
                }
               
                ?>
                </span>
        </a>
        <?
        if(isMobile()){
          ?>
            <a  href="#" style="font-size:10px;background:transparent" >&nbsp; </a>
            <a  href="#" style="font-size:10px;background:transparent">&nbsp; </a> 
          <?
        }else{
          ?>
            <a  href="#" style="font-size:10px;background:transparent" >&nbsp; </a>
            <a  href="#" style="font-size:10px;background:transparent">&nbsp; </a> 
            <a  href="#" style="font-size:10px;background:transparent" >&nbsp; </a>
            <a  href="#" style="font-size:10px;background:transparent">&nbsp; </a> 
            <a  href="#" style="font-size:10px;background:transparent" >&nbsp; </a>
            
          <?
        }
        ?>
       
				<a href="qrsayfa.php"><img src="images/icons/black/qr-code.png" alt="" title="" /><span><?php echo $dil["qrokut"];?></span></a>
			  <a href="kategori"><img src="images/icons/black/food.png" alt="" title="" /><span><?php echo $dil["menu"];?></span></a>
				<a href="siparis-durumu" data-popup=".popup-login" class="open-popup"><img src="images/icons/black/features.png" alt="" title="" /><span><?php echo $dil["siparis-durumu"];?></span></a>
				<a href="garson-cagir"><img src="images/icons/black/favorites.png" alt="" title="" /><span><?php echo $dil["garson-cagir"];?></span></a>

				<a href="hesap-iste"><img src="images/icons/black/search.png" alt="" title="" /><span><?php echo $dil["hesap-iste"];?></span></a> 

				<a href="alerji-listesi"><img src="images/icons/black/toggle.png" alt="" title="" /><span><?php echo $dil["alerjenbaslik"];?></span></a>

			  </div> 

			   

			</div>

		  </div>	



			  

            </div>

          </div>

        </div>







      </div>

    </div>

 

 <?php include 'includes/footer.php';?>