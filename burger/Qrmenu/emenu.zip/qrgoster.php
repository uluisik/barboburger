<?
 include __DIR__."/includes/siniflar/phpqrcode/qrlib.php";
    QRcode::png("1");

?>