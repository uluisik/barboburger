<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>ckeditor</title>
    <script src="ckeditor/ckeditor.js"></script>
</head>
<body>
<form>
    <textarea name="metin" id="metin" class="ckeditor"></textarea>
</form>
</body>
</html>