 <!-- Page Content Start -->

         <!--================================-->

         <div class="page-content">

            <!--================================-->

            <!-- Page Header Start -->

            <!--================================-->

            <div class="page-header">

               <div class="search-form">

                  <form action="#" method="GET">

                     <div class="input-group">

                        <input class="form-control search-input" name="search" placeholder="Type something..." type="text"/>

                        <span class="input-group-btn">

                        <span id="close-search"><i class="ion-ios-close-empty"></i></span>

                        </span>

                     </div>

                  </form>

               </div>

               <!--================================-->

               <!-- Page Header  Start -->

               <!--================================-->

               <nav class="navbar navbar-expand-lg">

                  <ul class="list-inline list-unstyled mg-r-20">

                     <!-- Mobile Toggle and Logo -->

                     <li class="list-inline-item align-text-top"><a class="hidden-md hidden-lg" href="#" id="sidebar-toggle-button"><i class="ion-navicon tx-20"></i></a></li>

                     <!-- PC Toggle and Logo -->

                     <li class="list-inline-item align-text-top"><a class="hidden-xs hidden-sm" href="#" id="collapsed-sidebar-toggle-button"><i class="ion-navicon tx-20"></i></a></li>

                  </ul>

                  <!--================================-->

                  <!-- Mega Menu Start -->

                  <!--================================-->

                  <div class="collapse navbar-collapse">

                     <ul class="navbar-nav mr-auto">

                        <!-- Features -->

                        <li class="dropdown mega-dropdown mg-t-5">

                          

                          

                        <!-- Technology -->

                        <li class="dropdown mega-dropdown mg-t-5">

                         

                           

                        <!-- Ecommerce -->

                        <li class="dropdown mega-dropdown mg-t-5">

                         

                          

                        </li>

                     </ul>

                  </div>

                  <!--/ Mega Menu End-->

                  <!--/ Brand and Logo End -->

                  <!--================================-->

                  <!-- Header Right Start -->

                  <!--================================-->

                  <div class="header-right pull-right">

                     <ul class="list-inline justify-content-end">

                      
<?php

                    $garson = $dbh->query("SELECT * FROM garson_cagir WHERE id ", PDO::FETCH_ASSOC);
                    $hesap = $dbh->query("SELECT * FROM hesap_iste WHERE id ", PDO::FETCH_ASSOC);
                    $siparis = $dbh->query("SELECT * FROM siparisler WHERE siparis_id ", PDO::FETCH_ASSOC);


            ?> 
                       

                        

                        <!--/ Languages Dropdown End -->

                        <!--================================-->

                        <!-- Notifications Dropdown Start -->

                        <!--================================-->

                        <li class="list-inline-item dropdown hidden-xs">

                           <a class="notification-icon" href="" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                           <i class="icon-bell tx-16"></i>

                           <span class="notification-count wave in"></span>

                           </a>

                           <div class="dropdown-menu dropdown-menu-right shadow-2">

                              <!-- Top Notifications Area -->

                              <div class="top-notifications-area">

                                 <!-- Heading -->

                                 <div class="notifications-heading">

                                    <div class="heading-title">

                                       <h6><center>Bildirimler</center></h6>

                                    </div>

                                    

                                 </div>

                                 <div class="notifications-box" id="notificationsBox">

                                    <a class="dropdown-item list-group-item" href="javascript:void(0)">

                                       <div class="d-flex justify-content-between">

                                          <div class="wd-45 ht-38 mg-r-15 d-flex align-items-center justify-content-center rounded-circle card-icon-success">

                                             <i class="fa fa-smile-o tx-success tx-16"></i>

                                          </div>

                                          <div>

                                             <span>

                                             <?=$siparis->rowCount()?> Adet

                                     </span> 

                                             <div class="tx-gray-600 tx-11">Yeni Gelen Sipariş Mevcut</div>

                                          </div>



                                       </div>

                                    </a>

                                    <a class="dropdown-item list-group-item" href="javascript:void(0)">

                                       <div class="d-flex justify-content-between">

                                          <div class="wd-45 ht-38 mg-r-15 d-flex align-items-center justify-content-center rounded-circle card-icon-success">

                                             <i class="fa fa-smile-o tx-success tx-16"></i>

                                          </div>

                                          <div>

                                             <span>

                                             <?=$garson->rowCount()?> Adet

                                     </span> 

                                             <div class="tx-gray-600 tx-11">Yeni Garson Talebi Mevcut</div>

                                          </div>

                                          

                                       </div>

                                    </a>

                                    <a class="dropdown-item list-group-item" href="javascript:void(0)">

                                       <div class="d-flex justify-content-between">

                                          <div class="wd-45 ht-38 mg-r-15 d-flex align-items-center justify-content-center rounded-circle card-icon-success">

                                             <i class="fa fa-smile-o tx-success tx-16"></i>

                                          </div>

                                          <div>

                                             <span>

                                             <?=$hesap->rowCount()?> Adet

                                     </span> 

                                             <div class="tx-gray-600 tx-11">Yeni Hesap Talebi Mevcut</div>

                                          </div>

                                          

                                       </div>

                                    </a>

                                    

                                 </div>

                                 <div class="notifications-footer">

                                    <a href="siparis-liste.php">Tüm Siparişleri Görüntüle</a>

                                 </div>

                              </div>

                           </div>

                        </li>

                        <!--/ Notifications Dropdown End -->

                        <!--================================-->

                        

                        <!-- Profile Dropdown Start -->

                        <!--================================-->

                        <li class="list-inline-item dropdown">

                           <a  href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="select-profile">Hoşgeldiniz, Sayın <?=$_SESSION["b"]["isim"]." ".$_SESSION["b"]["soyisim"]?></span><img src="assets/images/user/" class="img-fluid wd-35 ht-35 rounded-circle" alt=""></a> 
                        </li>

                        <!-- Profile Dropdown End -->

                        <!--================================-->

                        

                     </ul>

                  </div>

                  <!--/ Header Right End -->

               </nav>

            </div>

            <!--/ Page Header End -->

            <!--================================-->
 
               <div class="alert alert-success alert-bordered pd-y-15" role="alert" id="not">
                                 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true"><i class="ico icon-close"></i></span>
                                 </button>
                                 <div class="d-sm-flex align-items-center justify-content-start">
                                    <i class="icon ion-ios-checkmark alert-icon tx-52 mg-r-20 tx-success"></i>
                                    <div class="mg-t-20 mg-sm-t-0">
                                       <h5 class="mg-b-2 tx-success">Yeni Bir Hesap Talebi Geldi !</h5>
                                       <p class="mg-b-0 tx-gray">Yeni bir hesap talebi geldi <a href="hesap-liste.php"><b>buraya tıklayarak</b></a> ulaşabilirsiniz.</p>
                                    </div>
                                 </div>
                              </div>



          <div class="alert alert-success alert-bordered pd-y-15" role="alert" id="notgarson">
                                 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true"><i class="ico icon-close"></i></span>
                                 </button>
                                 <div class="d-sm-flex align-items-center justify-content-start">
                                    <i class="icon ion-ios-checkmark alert-icon tx-52 mg-r-20 tx-success"></i>
                                    <div class="mg-t-20 mg-sm-t-0">
                                       <h5 class="mg-b-2 tx-success">Yeni Garson Talebi Geldi Sayfayı Yenileyiniz!</h5>
                                       <p class="mg-b-0 tx-gray">Yeni bir garson talebi geldi <a href="garson-liste.php"><b>buraya tıklayarak</b></a> ulaşabilirsiniz.</p>
                                    </div>
                                 </div>
                              </div>                     


          <div class="alert alert-success alert-bordered pd-y-15" role="alert" id="notsiparis">
                                 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true"><i class="ico icon-close"></i></span>
                                 </button>
                                 <div class="d-sm-flex align-items-center justify-content-start">
                                    <i class="icon ion-ios-checkmark alert-icon tx-52 mg-r-20 tx-success"></i>
                                    <div class="mg-t-20 mg-sm-t-0">
                                       <h5 class="mg-b-2 tx-success">Yeni Sipariş Geldi Sayfayı Yenileyiniz!</h5>
                                       <p class="mg-b-0 tx-gray">Yeni bir sipariş geldi <a href="siparis-liste.php"><b>buraya tıklayarak</b></a> ulaşabilirsiniz.</p>
                                    </div>
                                 </div>
                              </div>                                           