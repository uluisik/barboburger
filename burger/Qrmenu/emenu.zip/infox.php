<?php
phpinfo();
phpinfo(INFO_MODULES);
?>